# will print "variables"
print(f"__name__ in variables.py: {__name__}")

name = "Keith Thompson"